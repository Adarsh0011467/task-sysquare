const Cust=require('../models/customer')


//created
exports.custformshow=(req,res)=>{
   res.render('custform.ejs')
}

exports.custform=async(req,res)=>{
   const{name,phone,age,gender,dob}=req.body
   //console.log(name,phone,age,gender,dob)
  let hobbies=req.body.h
  let hobby1
  let hobby2
  let hobby3
  if(hobbies.length==3){
  hobby1=hobbies[0]
  hobby2=hobbies[1]
  hobby3=hobbies[2]
  }
  else if(hobbies.length==2){
   hobby1=hobbies[0]
   hobby2=hobbies[1]
   hobby3=null
  }
  else if(hobbies.length==1){
   hobby1=hobbies[0]
   hobby2=null
   hobby3=null
  }
  else if(hobbies.length>=5){
    hobby1=hobbies
    hobby2=null
    hobby3=null
  }
  
 console.log(hobby1,hobby2,hobby3)
  const record=new Cust({name:name,phone:phone,age:age,DateofBirth:dob,Hobbies1:hobby1,Hobbies2:hobby2,Hobbies3:hobby3,gender:gender})
  await record.save()
  res.redirect('/selection')
}
//read
exports.selection=async(req,res)=>{
    const record =await Cust.find()
    res.render('selection.ejs',{record})
}
//delete
exports.custdelete=async(req,res)=>{
    const id=req.params.id;
    await Cust.findByIdAndDelete(id);
    res.redirect('/selection')
}
//update
exports.custupdate=async(req,res)=>{
    const id=req.params.id;
     const record=await Cust.findById(id);
    res.render('custupdateform.ejs',{record})
}

exports.custupdaterecord=async(req,res)=>{
    const id=req.params.id
    console.log(req.body)
  const {name,phone,age,dob,gender}=req.body
  console.log(req.body.h)
  let hobbies=req.body.h
  let hobby1
  let hobby2
  let hobby3
  if(hobbies.length==3){
  hobby1=hobbies[0]
  hobby2=hobbies[1]
  hobby3=hobbies[2]
  }
  else if(hobbies.length==2){
   hobby1=hobbies[0]
   hobby2=hobbies[1]
   hobby3=null
  }
  else if(hobbies.length==1){
   hobby1=hobbies[0]
   hobby2=null
   hobby3=null
  }
  else if(hobbies.length>=5){
    hobby1=hobbies
    hobby2=null
    hobby3=null
  }


   if(dob){
   await Cust.findByIdAndUpdate(id,{name:name,phone:phone,age:age,dob:dob,Hobbies1:hobby1,Hobbies2:hobby2,Hobbies3:hobby3,gender:gender})
  }
  else{
    await Cust.findByIdAndUpdate(id,{name:name,phone:phone,age:age,Hobbies1:hobby1,Hobbies2:hobby2,Hobbies3:hobby3,gender:gender})
  }
   res.redirect('/selection')
  }

  