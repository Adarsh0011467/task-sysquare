const Reg=require('../models/reg')
const bcrypt=require('bcrypt')


//signup page
exports.regshow=(req,res)=>{
   res.render('reg.ejs',{message:''})
}

exports.reg=async(req,res)=>{
    const{email,pass,name,phone,age,gender,dob}=req.body
    const convertedpass= await bcrypt.hash(pass,10)
    const hobbies=req.body.h
   let hobby1
   let hobby2
   let hobby3
   if(hobbies.length==3){
    hobby1=hobbies[0]
   hobby2=hobbies[1];
   hobby3=hobbies[2]
   }
   else if(hobbies.length==2){
    hobby1=hobbies[0]
    hobby2=hobbies[1]
    hobby3=null
   }
   else if(hobbies.length==1){
    hobby1=hobbies[0]
    hobby2=null;
    hobby3=null
   }
   else if(hobbies.length>=5){
    hobby1=hobbies
    hobby2=null;
    hobby3=null
   }
  // console.log(hobby1,hobby2,hobby3)
    const usercheck= await Reg.findOne({email:email})
    if(usercheck==null){
      const record= new Reg({email:email,password:convertedpass,name:name,phone:phone,age:age,DateofBirth:dob,Hobbies1:hobby1,Hobbies2:hobby2,Hobbies3:hobby3,gender:gender})
      record.save()
      res.redirect('/')
    }else{
           res.render('reg.ejs',{message:`${email} already exists`})
    }
}
 
//login page
exports.loginshow=(req,res)=>{
  res.render('login.ejs',{message:''})
}

exports.login=async(req,res)=>{
   const{email,pass}=req.body
   const record= await Reg.findOne({email})
   if(record!==null){
    const convertedpass=await bcrypt.compare(pass,record.password)
    if(convertedpass){
      req.session.isAuth=true
        res.redirect('/selection')
    }else{
        res.render('login.ejs',{message:'wrong credentials'})
    }
   }else{
    res.render('login.ejs',{message:'wrong credentials'})
   }
}