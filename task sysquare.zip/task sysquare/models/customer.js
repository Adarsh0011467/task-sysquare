const { default: mongoose } = require("mongoose");


const custSchema=mongoose.Schema({
    name:String,
    phone:Number,
    age:Number,
    Hobbies1:String,
    Hobbies2:String,
    Hobbies3:String,
    DateofBirth:Date,
    gender:String
})







module.exports=mongoose.model('customer',custSchema)