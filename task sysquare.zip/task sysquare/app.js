const express=require('express')
const app=express()
app.use(express.urlencoded({extended:false}))
const apiRouter=require('./routers/api')
const session=require('express-session')
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/sysquare')







app.use(session({
    secret:'adarsh',
    resave:false,
    saveUninitialized: false,
    //cookie:{maxAge}    
}))
app.use(apiRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000,()=>{console.log('this server is running on 5000')})
