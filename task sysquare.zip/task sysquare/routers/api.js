const router=require('express').Router();
const regc=require('../controllers/regcontroller')
const custc=require('../controllers/custcontroller')

//middleware function
function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}

//signup
router.get('/reg',regc.regshow)
router.post('/reg',regc.reg)
//signin
router.get('/',regc.loginshow)
router.post('/',regc.login)
//crud
router.get('/selection',handlelogin,custc.selection)
router.get('/custform',handlelogin,custc.custformshow)
router.post('/custform',custc.custform)
router.get('/custUpdate/:id',custc.custupdate)
router.post('/custrecordupdate/:id',custc.custupdaterecord)
router.get('/custdelete/:id',custc.custdelete)
//logout
router.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/')
   })














module.exports=router